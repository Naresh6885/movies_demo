extension ApiConstants {
    
    /// This structure contains all api parameter keys.
    enum Parameters: String {
        
        /// Parameter keys
        case api_key    = "api_key"
        case language   = "language"
        case page       = "page"
    }
}
