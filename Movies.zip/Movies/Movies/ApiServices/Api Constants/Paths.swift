extension ApiConstants {
    
    /// This structure cotains the  **Api Paths**
    enum Path {
    
        /// movies
        case movies
        
        ///Custome URLS
        case custom(String)
        
        ///This value will return the case's corresponding string value
        var value: String {
            
            switch self {
                
            case .movies:
                return "/movie/now_playing"
                
            case .custom(let url):
                return url
            }
        }
    }
}
