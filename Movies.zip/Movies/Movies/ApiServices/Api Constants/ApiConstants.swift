import Foundation

/// This structure contains **Base URL**, **Api Paths**, **Parameter Names** & **Status Codes**
enum ApiConstants: String {
    
    /// This is the base url used get
    case baseUrl = "https://api.themoviedb.org/3"
    
    /// Api key
    case apiKey = "1081bd76ab6cc6f28d0be89ad939e15a"
    
    /// language code
    case language = "en-US"
    
    /// Image base url
    case imageBaseURL = "https://image.tmdb.org/t/p/w500"
}
