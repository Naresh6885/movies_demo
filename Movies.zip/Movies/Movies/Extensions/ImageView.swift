import UIKit
import Kingfisher

/// ImageView Extension
extension UIImageView {
    
    /// Set the image from URL
    ///
    /// - Parameter userId: URL string of provided image.
    func setImage(from urlString: String) {
        
        guard let url = URL.init(string: urlString) else { return }
        let resouce = ImageResource.init(downloadURL: url, cacheKey: urlString)
        
        self.kf.setImage(with: resouce, placeholder: UIImage.init(named: "img_placeholder"), options: [.transition(ImageTransition.fade(1))])
    }
}
