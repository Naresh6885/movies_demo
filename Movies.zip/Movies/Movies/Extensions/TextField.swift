import UIKit

extension UITextField {
    
    
    /// This function will add the left image to the text field
    ///
    /// - Parameter image: UIImage view
    func setLeftImage(image: UIImage?, tintColor: UIColor? = nil) {
        
        let imageView = UIImageView.init(frame: CGRect.init(x: 0, y: 0, width: self.bounds.height, height: self.bounds.height))
        
        //if tint color is provided then set else don't set
        if(tintColor != nil) {
            imageView.image = image?.withRenderingMode(UIImage.RenderingMode.alwaysTemplate)
            imageView.tintColor = tintColor
        }
        else {
            imageView.image = image
        }
        
        imageView.contentMode = .center
        self.leftViewMode = .always
        self.leftView = imageView
    }
}
