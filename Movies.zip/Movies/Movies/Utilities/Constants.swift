import Foundation

enum  Constants: String {
    
    case recentSearchesKey = "RecentSearchesKey"
    
    case recentSearchTitle = "Recent Search"

}
