import Foundation

//This Model Belongs to the Movie listing model,
struct MoviesListingModel: Codable, Equatable {
    
    var results             : [MovieModel]?
    var page                : Int?
    var total_pages         : Int?
    var total_results       : Int?
    /* As we need only the search list, so we don't need the below objects */
 
    //definging the coding keys
    enum CodingKeys: String, CodingKey {
        case results         = "results"
        case page            = "page"
        case total_pages     = "total_pages"
        case total_results   = "total_results"
    }
    
    //decoding initializer
    init(from decoder: Decoder) throws {

        let container = try decoder.container(keyedBy: CodingKeys.self) // defining our (keyed) container

            results          = try? container.decode([MovieModel].self, forKey: .results)
            page             = try? container.decode(Int.self, forKey: .page)
            total_pages      = try? container.decode(Int.self, forKey: .total_pages)
            total_results    = try? container.decode(Int.self, forKey: .total_results)
    }
    
    static func == (lhs: MoviesListingModel, rhs: MoviesListingModel) -> Bool {
        return lhs.results == rhs.results
   }
}
