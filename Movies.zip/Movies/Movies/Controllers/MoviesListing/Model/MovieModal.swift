//This model belongs to the movie object model
struct MovieModel: Codable, Equatable {
    
    var popularity              : Double?
    var id                      : String?
    var vote_count              : Int?
    var vote_average            : Double?
    var release_date            : String?
    var title                   : String?
    var overview                : String?
    var poster_path             : String?
    var firstChar               : String?
    
    init() {

    }

    //definging the coding keys
    enum CodingKeys: String, CodingKey {
        case popularity         = "popularity"
        case id                 = "id"
        case vote_count         = "vote_count"
        case vote_average       = "vote_average"
        case release_date       = "release_date"
        case title              = "title"
        case overview           = "overview"
        case poster_path        = "poster_path"
    }
    
    //decoding initializer
    init(from decoder: Decoder) throws {

        let container = try decoder.container(keyedBy: CodingKeys.self) // defining our (keyed) container
        
        popularity          = try? container.decode(Double.self, forKey: .popularity)
        id                  = try? container.decode(String.self, forKey: .id)
        vote_count          = try? container.decode(Int.self, forKey: .vote_count)
        vote_average        = try? container.decode(Double.self, forKey: .vote_average)
        release_date        = try? container.decode(String.self, forKey: .release_date)
        title               = try? container.decode(String.self, forKey: .title)
        overview            = try? container.decode(String.self, forKey: .overview)
        poster_path         = try? container.decode(String.self, forKey: .poster_path)
        firstChar           = title?.components(separatedBy: .whitespaces).reduce("", { firstChar, y in
            let last = String(y.first ?? Character.init("_"))
            return (firstChar ?? "") + last
        })
    }
}
