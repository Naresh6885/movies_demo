import Foundation

class MoviesListViewModel {
    
    //This object is observed in view controller, when its value get updated the view get will updated
    var movieListingModel: Observable<MoviesListingModel> = Observable.init(nil)
    
    //this variable hold the temp storage of movies
    private var moviesDataSource: [MovieModel] = [MovieModel]()
    
    //This object is observed in view controller, when its value get updated the loading indicator get will updated
    var showIndicator: Observable<Bool> = Observable(false)
    
    //The default initialiser.
    init() {
        //Show loader & get data from server
        self.fetchMovies()
    }
    
    /// This will return the movie to table
    func getMovies()-> [MovieModel] {
        return self.movieListingModel.property?.results ?? []
    }
    
    
    /// This will return the movie at index [Section]
    /// - Parameter index: index
    func getMovie(at index: Int)-> MovieModel? {
        
        guard let data = self.movieListingModel.property?.results else { return nil }
        
        return index < data.count ? data[index] : nil
    }
    
    
    /// THis will fetch the movie from api
    func fetchMovies() {
        
        //Don't paginate records is search is happened on records
        if(!moviesDataSource.isEmpty || moviesDataSource.count > self.movieListingModel.property?.results?.count ?? 0) {
            return
        }
        //get the next page
        let page = (self.movieListingModel.property?.page ?? 0) + 1
        var reqModel = ApiRequestModel.init()
        reqModel.setPath(path:ApiConstants.Path.custom("\(ApiConstants.Path.movies.value)?\(ApiConstants.Parameters.api_key.rawValue)=\(ApiConstants.apiKey.rawValue)&\(ApiConstants.Parameters.language.rawValue)=\(ApiConstants.language.rawValue)&\(ApiConstants.Parameters.page.rawValue)=\(page)"))
        
        showIndicator.property = true
        ServiceManager.shared.dataGetTaskWith(apiRequestModel: reqModel, responseReciever: self, responseType: MoviesListingModel.self)
    }
    
    
    /// This func will filter movies movies
    /// - Parameter text: filter text
    func filterMovies(text: String) {
        
        //saving movies datasouce for later use
        if(self.moviesDataSource.isEmpty) {
            self.moviesDataSource = self.movieListingModel.property?.results ?? []
        }
        // temp datasource
        let tempDataSource = self.moviesDataSource
        
        let arrayOfSearchedStrins = text.components(separatedBy: .whitespaces)
        
        //In search field if there is empty string
        if(text.count == 0) {
            //load the previous data
            self.movieListingModel.property?.results = self.moviesDataSource
            self.moviesDataSource = []
        }
        else {
            self.saveSearchesItem(text: text)
            var filteredMovies = [MovieModel]()
            if(text.count == 1) {
                //filter movies with text with first letter of each word in movie title
                filteredMovies = tempDataSource.filter { (model) -> Bool in
                    let flag = (model.firstChar ?? "").contains(text)
                    return flag
                }
                
                
            }
            else if(arrayOfSearchedStrins.count == 1) {
                //If the user has typped the single work then check for that
                filteredMovies = tempDataSource.filter { (model) -> Bool in
                    let flag = model.title?.contains(arrayOfSearchedStrins[0])
                    return flag ?? false
                }
            }
            else {
                // user has typed the multiple words with space in between
                var dict: [String: Int] = [:]
                text.components(separatedBy: .whitespaces).forEach { (item) in
                    let str = item.lowercased()
                    dict[str] = dict[str] != nil ? ((dict[str] ?? 0) + 1) : 1
                }
                
                filteredMovies = tempDataSource.filter { (model) -> Bool in
                    
                    guard let tempTitle = model.title else { return false }
                    
                    var count = 0
                    
                    tempTitle.components(separatedBy: .whitespaces).forEach { (temp) in
                        let str = temp.lowercased()
                        if(dict[str] != nil) {
                            count += 1
                        }
                    }
                    
                    return (count >= dict.keys.count)
                }
                
            }
            self.movieListingModel.property?.results = filteredMovies
        }
    }
}

//MARK:- Api Response Handling
extension MoviesListViewModel {
    
    private func saveSearchesItem(text: String) {
        var data: [String] = UserDefaults.standard.stringArray(forKey: Constants.recentSearchesKey.rawValue) ?? []
        if(data.count == 5) {
            data.removeLast()
        }
        data.insert(text, at: 0)
        UserDefaults.standard.set(data, forKey: Constants.recentSearchesKey.rawValue)
        UserDefaults.standard.synchronize()
    }
    
    /// This will return the movie to table
    func getSearches()-> [String] {
        return UserDefaults.standard.stringArray(forKey: Constants.recentSearchesKey.rawValue) ?? []
    }
    
    
    /// This will return the movie at index [Section]
    /// - Parameter index: index
    func getSearch(at index: Int)-> String? {
        guard let data = UserDefaults.standard.stringArray(forKey: Constants.recentSearchesKey.rawValue) else { return nil }
        return index < data.count ? data[index] : nil
    }
}


//MARK:- Api Response Handling
extension MoviesListViewModel: BaseResponseDelegate {
    
    
    /// This api success callback
    /// - Parameter responseModel: the response of api
    func sucess<T>(responseModel: T) where T : Decodable, T : Encodable {
        
        showIndicator.property = false
        var response = responseModel as! MoviesListingModel
        
        let dataSource = (movieListingModel.property?.results ?? []) + (response.results ?? [])
        
        response.results = dataSource
        
        self.movieListingModel.property = response
    }
    
    /// This will return the error of api
    /// - Parameter errorModel: error model
    func failure(errorModel: ErrorResponseModel) {
        
        showIndicator.property = false
    }
}

