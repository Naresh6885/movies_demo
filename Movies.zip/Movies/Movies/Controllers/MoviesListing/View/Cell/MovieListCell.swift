import UIKit

class MovieListCell: UICollectionViewCell {

    //MARK:- Outlets
    @IBOutlet weak var nameLabel    : UILabel!
    @IBOutlet weak var yearLabel    : UILabel!
    @IBOutlet weak var imgView      : UIImageView!
    @IBOutlet weak var bookNowButton : UIButton!

    //MARK:- Constants & Variables
    /// This will hold the movie pbject
    private var movie: MovieModel? 

    //MARK:- Life cycle functions
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    //MARK:- Binding
    
    /// This function will bind the cell with modal data
    ///
    /// - Parameters:
    ///   - movie: Movie Modal
    ///   - indexPath: Index Path of the object
    func bind(with movie: MovieModel? ) {
        
        self.movie = movie
        
        //This will setup the UI
        self.setupUI()
    }
    
    
    /// This will setup the UI part
    private func setupUI() {
        self.nameLabel.text = self.movie?.title ?? ""
                    
        self.yearLabel.text = self.movie?.release_date ?? ""
         
        if let path = self.movie?.poster_path {
            self.imgView.setImage(from: "\(ApiConstants.imageBaseURL.rawValue)\(path)")
        }
        
        bookNowButton.layer.masksToBounds = true
        bookNowButton.layer.cornerRadius = 5
        bookNowButton.backgroundColor = .clear
        bookNowButton.layer.borderColor = UIColor.green.cgColor
        bookNowButton.layer.borderWidth = 1
        bookNowButton.setTitleColor(.green, for: .normal)
    }
}
