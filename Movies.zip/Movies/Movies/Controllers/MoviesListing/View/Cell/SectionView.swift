import UIKit

class SectionView: UITableViewHeaderFooterView {
    
    @IBOutlet weak var nameLabel: UILabel!
    
    static let HEIGHT: CGFloat = 44.0
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    func bind(text: String) {
                
        self.nameLabel.text = text
    }
}
