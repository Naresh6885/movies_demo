import UIKit

class MoviesListingView: UIViewController {

    //MARK:- Outlets
    @IBOutlet weak var movieListCollectionView  : UICollectionView!
    @IBOutlet weak var searchTextField          : UITextField!
    @IBOutlet weak var recentSearches           : UITableView!

    
     //MARK:-
       private var viewModel: MoviesListViewModel? {
           didSet {
               self.observer()
           }
       }
       
       override func viewDidLoad() {
           super.viewDidLoad()
           // Do any additional setup after loading the view.
           self.initialSetup()
       }
       
       private func initialSetup() {
            self.recentSearches.isHidden = true
            self.setupCollectionViewCell()
            self.setupSearchField()
            self.viewModel = MoviesListViewModel.init()
        self.registerTableCellsAndSections()
       }
       
       private func observer() {
           
           self.viewModel?.showIndicator.observe = { [weak self] value in
               self?.loader(flag: value)
           }
           
        self.viewModel?.movieListingModel.observe = { [weak self] value in
               self?.movieListCollectionView.reloadData()
           }
       }
    
    /// This action will be called to hide the keyboard on tap of screen are
    ///
    /// - Parameter sender: Tap Gesture
    @IBAction func screenAreaTapped(_ sender: UITapGestureRecognizer) {
        self.view.endEditing(true)
    }
}


//MARK:- UISetup
extension MoviesListingView {
    
    /// This function will setup the collection view.
    private func setupCollectionViewCell() {
        
        let nibName = String.init(describing: MovieListCell.self)
        self.movieListCollectionView.register(UINib.init(nibName: nibName, bundle: nil), forCellWithReuseIdentifier: nibName)
    }
    
    
    /// This will configure the search field
    private func setupSearchField() {
        self.searchTextField.setLeftImage(image: UIImage.init(named: "ic_search"), tintColor: UIColor.init(white: 1.0, alpha: 0.5))
        searchTextField.attributedPlaceholder =
            NSAttributedString(string: "Search Movies", attributes: [NSAttributedString.Key.foregroundColor: UIColor.init(white: 1.0, alpha: 0.5)])
    }
}


//MARK:- UISetup
extension MoviesListingView: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return self.viewModel?.getMovies().count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let nibName = String.init(describing: MovieListCell.self)
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: nibName, for: indexPath) as! MovieListCell
        cell.bind(with: self.viewModel?.getMovie(at: indexPath.row))
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        //self.showDetails(of: self.movies[indexPath.row])
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let itemWidth =  ( collectionView.frame.size.width - 20 ) / 2
        
        return CGSize.init(width: itemWidth, height: itemWidth * 2.2)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 6.5
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        
        return UIEdgeInsets.init(top: 0, left: 0, bottom: 0, right: 0 )
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 5
    }
}

//MARK:-
extension MoviesListingView: UIScrollViewDelegate {
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        let tempOffset = scrollView.contentSize.height - self.view.frame.size.height - 400
        if (scrollView.contentOffset.y >= tempOffset) {
            viewModel?.fetchMovies()
        }
    }
}


//MARK:- TextField Delegates
extension MoviesListingView: UITextFieldDelegate {
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        self.recentSearches.isHidden = false
        self.recentSearches.reloadData()
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        self.recentSearches.isHidden = true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        guard let text = textField.text else { return true }
        
        self.viewModel?.filterMovies(text: text)
        
        textField.resignFirstResponder()
        
        return true
    }
}


//MARK:- TableView
extension MoviesListingView: UITableViewDelegate, UITableViewDataSource {
    
    private func registerTableCellsAndSections() {
        
        let sectionViewIdentifier = String(describing: SectionView.self)
        self.recentSearches.register(UINib.init(nibName: sectionViewIdentifier, bundle: nil), forHeaderFooterViewReuseIdentifier: sectionViewIdentifier)
        
        let cellIdentifier = String(describing: RecentSearchCell.self)
        self.recentSearches.register(UINib.init(nibName: cellIdentifier, bundle: nil), forCellReuseIdentifier: cellIdentifier)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.viewModel?.getSearches().count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cellIdentifier = String(describing: RecentSearchCell.self)
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as? RecentSearchCell else { return UITableViewCell.init() }
              
        guard let text = self.viewModel?.getSearch(at: indexPath.row) else { return cell }
        
        cell.bind(text: text)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
                
        let sectionViewIdentifier = String(describing: SectionView.self)
        
        guard let section = tableView.dequeueReusableHeaderFooterView(withIdentifier: sectionViewIdentifier) as? SectionView else { return nil }
        
        section.bind(text: Constants.recentSearchTitle.rawValue)
        
        return section
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        
        return SectionView.HEIGHT
    }
}
